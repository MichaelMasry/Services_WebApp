const express = require('express');
const mysql = require('mysql');


// Create connection
const db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'services'
});

// Connect
db.connect((err) => {
    if(err){
        throw err;
    }
    console.log('MySql Connected...');
});

const app = express();
app.use(express.urlencoded());

app.post('/addnewtask', (req, res) => {
    const task_name = req.body.name
    const task_date = req.body.date
    const task_description = req.body.description
    const user_id = req.body.user_id
    let task = {name:`${task_name}`, due_date:`${task_date}`,
     description:`${task_description}`,user_id:`${user_id}`};
    let sql = 'INSERT INTO tasks SET ?';
    let query = db.query(sql, task, (err, result) => {
        if(err){
            console.log(err)
            throw err;
        }
        console.log(result);
        res.send(JSON.stringify({ id: result.insertId }));
    });
});

app.post('/signup', (req, res) => {
    const user_name = req.body.username
    let user = {user_name:`${user_name}`};
    let sql = 'INSERT INTO users SET ?';
    let query = db.query(sql, user, (err, result) => {
        if(err){
            console.log(err)
            throw err;
        }
        console.log(result);
        res.send(JSON.stringify({ id: result.insertId }));
    });
});

// Select posts
app.get('/allmytasks', (req, res) => {
    const id = req.body.user_id
    let sql = `SELECT name, due_date, description FROM tasks WHERE user_id=${id};`;
    let query = db.query(sql, (err, results) => {
        if(err){
            console.log(err)
            throw err;
        }
        console.log(results);
        res.send(JSON.stringify(results));
    });
});

// Select single post
app.get('/rvtask', (req, res) => {
    id = req.query.id
    let sql = `SELECT name, due_date, description FROM tasks WHERE id=${id}`;
    let query = db.query(sql, (err, result) => {
        if(err){
            console.log(err)
            throw err;
        }
        console.log(result);
        res.send(JSON.stringify(result));
    });
});

// Update post
app.get('/updatepost', (req, res) => {
    let newTitle = req.body.name;
    let due_date = req.body.due_date;
    let description = req.body.description;
    if(newTitle != undefined){
        let sql = `UPDATE tasks SET name = ${newTitle} WHERE id = ${req.query.id}`;
    }
    else if (due_date != undefined) {
        let sql = `UPDATE tasks SET due_date = ${due_date} WHERE id = ${req.query.id}`;
    }
    else if (description != undefined) {
        let sql = `UPDATE tasks SET description = ${description} WHERE id = ${req.query.id}`;
    }
    let query = db.query(sql, (err, result) => {
        if(err) throw err;
        console.log(result);
        res.send('Post updated...');
    });
});

// Delete post
app.get('/deletetask', (req, res) => {
    let sql = `DELETE FROM tasks WHERE id = ${req.query.id}`;
    let query = db.query(sql, (err, result) => {
        if(err){
            console.log(err)
            throw err;
        }
        console.log("done");
        res.send("done");
    });
});

app.listen('3000', () => {
    console.log('Server started on port 3000');
});